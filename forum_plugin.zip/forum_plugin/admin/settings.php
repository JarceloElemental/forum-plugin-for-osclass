User can edit thir topic
User can edit thir reply
User can delete thir topic
User can delete thir reply
Only logged user can create new topic
Only logged user can create new reply
Only logged user can read reply

Ad area
header 720
Footer 720
create topic right 320
Between the 2 replies 720
Inner reply 720



Forum Bugs
Forum search
Text area script

Hooks
Header Hook
Search Hook
between 2 or every reply hook
inner reply hook 
Reply action hook
Footer Hook
